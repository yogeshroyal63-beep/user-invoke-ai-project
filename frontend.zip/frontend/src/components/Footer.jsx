export default function Footer() {
  return (
    <footer className="text-center py-6 text-slate-500 border-t border-white/10">
      © 2026 TrustCheck AI
    </footer>
  );
}
