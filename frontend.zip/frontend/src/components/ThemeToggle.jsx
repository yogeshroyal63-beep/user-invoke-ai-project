export default function ThemeToggle() {
  return <button>🌙</button>;
}
